package br.edu.ifg;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Busca {
	
	public static void main(String[] args) throws IOException {
		
	BufferedReader b  = new BufferedReader(new FileReader("c:\\Users\\fabio\\eclipse-workspace\\ProvaFinal\\texto.txt"));

	StringBuffer texto = new StringBuffer();
	String linha = null;
	while((linha = b.readLine()) !=null){
		texto.append(linha);
	}
	
// pedir ao usuario a entrada do artigo	
//	System.out.print("Digite o artigo a ser pesquisado: ");
//	String artigo = new Scanner(System.in).next();

	String artigo = "no";

	
	Matcher pesquisa = Pattern.compile(artigo).matcher(texto);
	int numeroDeArtigo = 0;
	while (pesquisa.find()){
		numeroDeArtigo++;
	}
	
	System.out.println("O artigo "+ "'"+ artigo +"'" +" foi encontrado no documento: " + numeroDeArtigo + " vezes");
	
	b.close();

	}
}