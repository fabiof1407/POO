package br.edu.ifg;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Criar {

	public static void main(String[] args) {
		
		String [] linhas = new String [] {"Prova", "POO I", "Dia","07","Dezembro"};

		String path = "c:\\Users\\fabio\\eclipse-workspace\\ProvaFinal\\prova.txt";
			
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))){ //com o true ele adiciona nova coisas digitas no vetor de String no arquivo
			for (String linha : linhas) {											// sem "true" ir� adicionar apenas a nova palavra
				bw.write(linha);
				bw.newLine();
			}
			System.out.println("Arquivo Criado com Sucesso!");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

}
